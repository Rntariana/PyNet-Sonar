#!/usr/bin/env python3
"""
PyNet Network Scanner
---------------------
Discovers devices on a local network: online status, IP, MAC, hostname,
open ports and common services. Exports CSV and a text report.

Only scan networks you own or have permission to test.

Usage:
    python pynet.py                          # auto-detect your /24 network
    python pynet.py 192.168.1.0/24
    python pynet.py 192.168.1.0/24 -p 22,80,443 --csv results.csv --report report.txt
    python pynet.py --gui
"""
import argparse
import csv
import ipaddress
import platform
import re
import socket
import subprocess
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime

COMMON_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP",
    110: "POP3", 139: "NetBIOS", 143: "IMAP", 443: "HTTPS", 445: "SMB",
    3306: "MySQL", 3389: "RDP", 8080: "HTTP-Alt",
}
SYSTEM = platform.system()


@dataclass
class Device:
    ip: str
    online: bool = False
    hostname: str = "Unknown"
    mac: str = "-"
    ports: list = field(default_factory=list)

    def services(self):
        return ", ".join(f"{p}/{COMMON_PORTS.get(p, self._svc(p))}" for p in self.ports) or "-"

    @staticmethod
    def _svc(port):
        try:
            return socket.getservbyport(port)
        except OSError:
            return "unknown"


# ---------- core scanning ----------
def local_network():
    """Guess the local /24 from the machine's outbound IP."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))  # no packet is sent for UDP connect
        ip = s.getsockname()[0]
    except OSError:
        ip = "192.168.1.1"
    finally:
        s.close()
    return str(ipaddress.ip_network(f"{ip}/24", strict=False))


def ping(ip, timeout=1):
    if SYSTEM == "Windows":
        cmd = ["ping", "-n", "1", "-w", str(timeout * 1000), ip]
    elif SYSTEM == "Darwin":
        cmd = ["ping", "-c", "1", "-W", str(timeout * 1000), ip]
    else:
        cmd = ["ping", "-c", "1", "-W", str(timeout), ip]
    try:
        return subprocess.run(cmd, stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL).returncode == 0
    except FileNotFoundError:
        return False


def arp_table():
    """Return {ip: mac} parsed from the OS ARP cache."""
    try:
        out = subprocess.run(["arp", "-a"], capture_output=True, text=True).stdout
    except FileNotFoundError:
        return {}
    pattern = re.compile(r"(\d{1,3}(?:\.\d{1,3}){3}).*?([0-9a-fA-F]{1,2}(?:[:-][0-9a-fA-F]{1,2}){5})")
    table = {}
    for line in out.splitlines():
        m = pattern.search(line)
        if m:
            mac = ":".join(x.zfill(2) for x in re.split(r"[:-]", m.group(2))).upper()
            if mac != "FF:FF:FF:FF:FF:FF":
                table[m.group(1)] = mac
    return table


def resolve_host(ip):
    try:
        return socket.gethostbyaddr(ip)[0]
    except (socket.herror, socket.gaierror, OSError):
        return "Unknown"


def port_open(ip, port, timeout=0.5):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(timeout)
        return s.connect_ex((ip, port)) == 0


def scan_host(ip, ports):
    dev = Device(ip=ip, online=ping(ip))
    if dev.online:
        dev.hostname = resolve_host(ip)
        dev.ports = [p for p in ports if port_open(ip, p)]
    return dev


def scan_network(cidr, ports, workers=64, progress=None):
    net = ipaddress.ip_network(cidr, strict=False)
    hosts = [str(h) for h in (net.hosts() if net.num_addresses > 2 else net)]
    done = 0
    lock = threading.Lock()

    def task(ip):
        nonlocal done
        dev = scan_host(ip, ports)
        with lock:
            done += 1
            if progress:
                progress(done, len(hosts))
        return dev

    with ThreadPoolExecutor(max_workers=workers) as pool:
        devices = list(pool.map(task, hosts))

    macs = arp_table()  # read after pings so the cache is populated
    for d in devices:
        if d.online:
            d.mac = macs.get(d.ip, "-")
    return devices


# ---------- output ----------
def format_report(devices, cidr, seconds):
    line = "=" * 78
    online = [d for d in devices if d.online]
    out = [
        "╔" + "═" * 38 + "╗",
        "║" + "PYNET NETWORK SCANNER".center(38) + "║",
        "╚" + "═" * 38 + "╝",
        "",
        f"Scanning : {cidr}",
        f"Time     : {datetime.now():%Y-%m-%d %H:%M:%S}",
        "",
        f"{'IP Address':<16}{'Status':<9}{'MAC':<19}{'Host':<22}Open ports",
        line,
    ]
    for d in devices:
        out.append(f"{d.ip:<16}{'ONLINE' if d.online else 'OFFLINE':<9}"
                   f"{d.mac:<19}{d.hostname[:20]:<22}{d.services() if d.online else ''}")
    out += [line, f"Scan completed: {len(devices)} addresses checked, "
                  f"{len(online)} online, {len(devices) - len(online)} offline "
                  f"({seconds:.1f}s)"]
    return "\n".join(out)


def export_csv(devices, path):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["IP", "Status", "MAC", "Hostname", "Open Ports", "Services"])
        for d in devices:
            w.writerow([d.ip, "ONLINE" if d.online else "OFFLINE", d.mac, d.hostname,
                        ";".join(map(str, d.ports)), d.services()])


def parse_ports(text):
    if not text:
        return sorted(COMMON_PORTS)
    return sorted({int(p) for p in text.split(",") if p.strip()})


# ---------- GUI ----------
def run_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title("PyNet Network Scanner")
    root.geometry("860x480")
    devices = []

    top = ttk.Frame(root, padding=8)
    top.pack(fill="x")
    net_var = tk.StringVar(value=local_network())
    port_var = tk.StringVar(value=",".join(map(str, sorted(COMMON_PORTS))))
    ttk.Label(top, text="Network:").pack(side="left")
    ttk.Entry(top, textvariable=net_var, width=18).pack(side="left", padx=4)
    ttk.Label(top, text="Ports:").pack(side="left")
    ttk.Entry(top, textvariable=port_var, width=32).pack(side="left", padx=4)

    cols = ("IP", "Status", "MAC", "Host", "Services")
    tree = ttk.Treeview(root, columns=cols, show="headings")
    for c, w in zip(cols, (120, 70, 140, 200, 300)):
        tree.heading(c, text=c)
        tree.column(c, width=w)
    tree.pack(fill="both", expand=True, padx=8)
    status = tk.StringVar(value="Ready")
    ttk.Label(root, textvariable=status, padding=6).pack(fill="x")

    def worker(cidr, ports):
        nonlocal devices
        start = datetime.now()
        try:
            devices = scan_network(cidr, ports, progress=lambda d, t: root.after(
                0, status.set, f"Scanning... {d}/{t}"))
        except ValueError as e:
            root.after(0, messagebox.showerror, "Error", str(e))
            root.after(0, status.set, "Ready")
            return
        secs = (datetime.now() - start).total_seconds()

        def show():
            tree.delete(*tree.get_children())
            for d in devices:
                tree.insert("", "end", values=(d.ip, "ONLINE" if d.online else "OFFLINE",
                                               d.mac, d.hostname, d.services()))
            status.set(f"Done: {sum(d.online for d in devices)} online of "
                       f"{len(devices)} in {secs:.1f}s")
        root.after(0, show)

    def start_scan():
        try:
            ports = parse_ports(port_var.get())
        except ValueError:
            messagebox.showerror("Error", "Ports must be numbers separated by commas")
            return
        status.set("Scanning...")
        threading.Thread(target=worker, args=(net_var.get(), ports), daemon=True).start()

    def save_csv():
        if not devices:
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv")
        if path:
            export_csv(devices, path)
            status.set(f"Saved {path}")

    ttk.Button(top, text="Scan", command=start_scan).pack(side="left", padx=4)
    ttk.Button(top, text="Export CSV", command=save_csv).pack(side="left")
    root.mainloop()


# ---------- CLI ----------
def main():
    ap = argparse.ArgumentParser(description="PyNet network scanner")
    ap.add_argument("network", nargs="?", help="CIDR range, e.g. 192.168.1.0/24 (default: auto)")
    ap.add_argument("-p", "--ports", help="comma-separated ports (default: common ports)")
    ap.add_argument("--csv", help="export results to this CSV file")
    ap.add_argument("--report", help="save the text report to this file")
    ap.add_argument("--online-only", action="store_true", help="hide offline addresses")
    ap.add_argument("--gui", action="store_true", help="launch the Tkinter GUI")
    args = ap.parse_args()

    if args.gui:
        return run_gui()

    cidr = args.network or local_network()
    try:
        ports = parse_ports(args.ports)
        ipaddress.ip_network(cidr, strict=False)
    except ValueError as e:
        sys.exit(f"Invalid input: {e}")

    print(f"Scanning {cidr} ...")
    start = datetime.now()
    devices = scan_network(
        cidr, ports,
        progress=lambda d, t: print(f"\r  {d}/{t}", end="", flush=True))
    print()
    if args.online_only:
        devices = [d for d in devices if d.online]
    report = format_report(devices, cidr, (datetime.now() - start).total_seconds())
    print(report)

    if args.csv:
        export_csv(devices, args.csv)
        print(f"CSV saved to {args.csv}")
    if args.report:
        with open(args.report, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"Report saved to {args.report}")


if __name__ == "__main__":
    main()
