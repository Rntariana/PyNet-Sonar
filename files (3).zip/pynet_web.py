#!/usr/bin/env python3
"""
PyNet Web - a sonar-style browser dashboard for pynet.py.
Put this file next to pynet.py, then run:

    python pynet_web.py            # opens http://127.0.0.1:8765

The server only listens on your own machine. Scan networks you own or have
permission to test.
"""
import csv
import io
import ipaddress
import json
import threading
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pynet

PORT = 8765
state = {"running": False, "done": 0, "total": 0, "devices": [],
         "network": "", "seconds": 0.0, "error": ""}


def run_scan(cidr, ports):
    start = datetime.now()

    def progress(d, t):
        state.update(done=d, total=t)

    try:
        devs = pynet.scan_network(cidr, ports, progress=progress)
        state["devices"] = [
            {"ip": d.ip, "online": d.online, "mac": d.mac, "host": d.hostname,
             "ports": [{"port": p, "name": pynet.COMMON_PORTS.get(p) or pynet.Device._svc(p)}
                       for p in d.ports]} for d in devs]
    except Exception as e:  # report any failure to the page
        state["error"] = str(e)
    state.update(seconds=(datetime.now() - start).total_seconds(), running=False)


def csv_bytes():
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["IP", "Status", "MAC", "Hostname", "Open Ports"])
    for d in state["devices"]:
        w.writerow([d["ip"], "ONLINE" if d["online"] else "OFFLINE", d["mac"], d["host"],
                    ";".join(f"{p['port']}/{p['name']}" for p in d["ports"])])
    return buf.getvalue().encode()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json", extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/":
            self.send(200, PAGE.replace("__NET__", pynet.local_network()).encode(), "text/html; charset=utf-8")
        elif self.path == "/api/status":
            self.send(200, json.dumps(state).encode())
        elif self.path == "/api/csv":
            self.send(200, csv_bytes(), "text/csv",
                      {"Content-Disposition": 'attachment; filename="pynet-scan.csv"'})
        else:
            self.send(404, b"{}")

    def do_POST(self):
        if self.path != "/api/scan":
            return self.send(404, b"{}")
        if state["running"]:
            return self.send(409, b'{"error":"A scan is already running."}')
        try:
            data = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
            net = ipaddress.ip_network(data["network"].strip(), strict=False)
            if net.version != 4 or net.prefixlen < 22:
                raise ValueError("Use an IPv4 range of /22 or smaller (up to 1,024 addresses).")
            ports = pynet.parse_ports(data.get("ports", ""))
            if len(ports) > 100 or any(not 0 < p < 65536 for p in ports):
                raise ValueError("Ports must be 1-65535, up to 100 of them.")
        except (ValueError, KeyError, json.JSONDecodeError) as e:
            return self.send(400, json.dumps({"error": str(e)}).encode())
        state.update(running=True, done=0, total=0, devices=[], network=str(net), error="")
        threading.Thread(target=run_scan, args=(str(net), ports), daemon=True).start()
        self.send(202, b"{}")


PAGE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PyNet - who is on your network</title>
<style>
:root{
  --deep:#0b2239; --sea:#123a5a; --line:#2b5878; --foam:#dcece7; --mute:#8fb0b8;
  --amber:#ffb238; --coral:#ff7a66; --serif:"Iowan Old Style","Palatino Linotype",Palatino,Georgia,serif;
  --mono:ui-monospace,"SF Mono","Cascadia Code",Consolas,monospace;
}
*{box-sizing:border-box}
html,body{margin:0;background:var(--deep);color:var(--foam);font:16px/1.5 var(--serif)}
body{min-height:100vh;display:grid;grid-template-columns:minmax(320px,1fr) minmax(360px,1.1fr);gap:0}
@media(max-width:860px){body{grid-template-columns:1fr}}
button,input{font:inherit;color:inherit}
:focus-visible{outline:2px solid var(--amber);outline-offset:2px}

/* left: the sonar */
.scope{padding:clamp(20px,4vw,48px);background:radial-gradient(circle at 50% 42%,var(--sea),var(--deep) 70%);
  display:flex;flex-direction:column;gap:20px;align-items:center;justify-content:center}
h1{margin:0;font-weight:400;font-size:clamp(2rem,4.5vw,3.4rem);letter-spacing:-.02em;align-self:flex-start;line-height:1.05}
h1 i{color:var(--amber)}
.tag{margin:0;color:var(--mute);align-self:flex-start;max-width:34ch}
svg{width:min(100%,520px);height:auto;overflow:visible}
.ring{fill:none;stroke:var(--line);stroke-width:1}
.axis{stroke:var(--line);stroke-width:1;stroke-dasharray:2 5}
.sweep{transform-origin:200px 200px;opacity:0}
.scanning .sweep{opacity:1;animation:spin 2.4s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.blip{fill:var(--amber);cursor:pointer;transition:r .15s}
.blip:hover,.blip.on{r:9}
.blip.on{stroke:var(--foam);stroke-width:2}
.halo{fill:none;stroke:var(--amber);opacity:.35}
.hub{fill:var(--foam)}
.count{font:400 44px var(--serif);fill:var(--foam);text-anchor:middle}
.sub{font:13px var(--serif);fill:var(--mute);text-anchor:middle}
@media(prefers-reduced-motion:reduce){.scanning .sweep{animation:none}}

/* right: the roster */
.roster{padding:clamp(20px,4vw,48px);background:var(--foam);color:#10283a;display:flex;flex-direction:column;gap:18px}
form{display:grid;grid-template-columns:1fr auto;gap:10px 12px;align-items:end}
label{display:flex;flex-direction:column;font-size:.85rem;color:#3d5b6b;gap:3px}
input{padding:9px 11px;border:1px solid #9db8bd;border-radius:6px;background:#fff;color:#10283a;font-family:var(--mono);font-size:.9rem}
.ports{grid-column:1/2}
.go{grid-row:1/3;grid-column:2;align-self:stretch;padding:0 22px;border:0;border-radius:6px;background:var(--deep);color:var(--foam);cursor:pointer;font-size:1rem}
.go:hover{background:var(--sea)} .go[disabled]{opacity:.55;cursor:progress}
@media(max-width:520px){form{grid-template-columns:1fr}.go{grid-row:auto;grid-column:1;padding:11px}.ports{grid-column:1}}
.bar{height:3px;background:#c4d8d6;border-radius:2px;overflow:hidden}
.bar b{display:block;height:100%;width:0;background:var(--deep);transition:width .3s}
.msg{margin:0;min-height:1.5em;font-size:.95rem;color:#3d5b6b}
.msg.err{color:#b23a26}
ul{list-style:none;margin:0;padding:0;border-top:1px solid #b7cdcc}
li{padding:12px 4px;border-bottom:1px solid #b7cdcc;display:grid;grid-template-columns:auto 1fr;gap:2px 12px;cursor:pointer}
li.on{background:#cfe4de}
li .dot{grid-row:1/3;width:10px;height:10px;border-radius:50%;background:var(--amber);margin-top:.45em;box-shadow:0 0 0 3px #ffb23840}
li.off .dot{background:var(--coral);box-shadow:none}
li .ip{font:600 1rem var(--mono)}
li .meta{color:#3d5b6b;font-size:.9rem;overflow-wrap:anywhere}
.chips{grid-column:2;display:flex;flex-wrap:wrap;gap:6px;margin-top:4px}
.chips span{font:.78rem var(--mono);padding:1px 8px;border:1px solid #6f8f97;border-radius:99px}
.foot{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-top:auto}
.link{background:none;border:0;padding:0;text-decoration:underline;cursor:pointer;color:#10283a}
.link[disabled]{opacity:.4;cursor:default}
</style></head>
<body id="app">
<section class="scope" aria-label="Network radar">
  <h1>Py<i>Net</i></h1>
  <p class="tag">Every device that answers on your network shows up as a blip. Click one to see its details.</p>
  <svg viewBox="0 0 400 400" role="img" aria-label="Radar of discovered devices">
    <defs><linearGradient id="wedge" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="#ffb238" stop-opacity="0"/><stop offset="1" stop-color="#ffb238" stop-opacity=".5"/></linearGradient></defs>
    <circle class="ring" cx="200" cy="200" r="60"/><circle class="ring" cx="200" cy="200" r="120"/><circle class="ring" cx="200" cy="200" r="180"/>
    <line class="axis" x1="20" y1="200" x2="380" y2="200"/><line class="axis" x1="200" y1="20" x2="200" y2="380"/>
    <g class="sweep"><path d="M200 200 L200 20 A180 180 0 0 1 300 50 Z" transform="rotate(-30 200 200)" fill="url(#wedge)"/></g>
    <g id="blips"></g>
    <text class="count" x="200" y="196" id="count">-</text>
    <text class="sub" x="200" y="218" id="sub">Ready to scan</text>
  </svg>
</section>
<main class="roster">
  <form id="f">
    <label>Network range<input id="net" value="__NET__" spellcheck="false"></label>
    <label class="ports">Ports to check<input id="ports" value="21,22,23,25,53,80,110,139,143,443,445,3306,3389,8080" spellcheck="false"></label>
    <button class="go" id="go">Scan network</button>
  </form>
  <div class="bar"><b id="prog"></b></div>
  <p class="msg" id="msg" role="status">Press Scan network to look for devices.</p>
  <ul id="list"></ul>
  <div class="foot"><span class="msg" id="time"></span><button class="link" id="csv" disabled>Download CSV</button></div>
</main>
<script>
const $=id=>document.getElementById(id), svgNS="http://www.w3.org/2000/svg";
let devices=[], selected=null, timer=null;
const el=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!==undefined)e.textContent=x;return e};

$("f").onsubmit=async e=>{
  e.preventDefault();
  const r=await fetch("/api/scan",{method:"POST",body:JSON.stringify({network:$("net").value,ports:$("ports").value})});
  if(!r.ok){setMsg((await r.json()).error,true);return}
  devices=[];render();$("app").classList.add("scanning");$("go").disabled=true;$("csv").disabled=true;
  $("count").textContent="...";$("sub").textContent="Listening";
  timer=setInterval(poll,500);
};
async function poll(){
  const s=await (await fetch("/api/status")).json();
  $("prog").style.width=(s.total?100*s.done/s.total:0)+"%";
  setMsg(s.running?`Checked ${s.done} of ${s.total||"?"} addresses`:"");
  if(s.running)return;
  clearInterval(timer);$("app").classList.remove("scanning");$("go").disabled=false;
  if(s.error){setMsg(s.error,true);$("count").textContent="-";$("sub").textContent="Scan failed";return}
  devices=s.devices;
  const on=devices.filter(d=>d.online).length;
  $("count").textContent=on;$("sub").textContent=on===1?"device online":"devices online";
  $("time").textContent=`${devices.length} addresses in ${s.seconds.toFixed(1)}s, ${devices.length-on} silent`;
  setMsg(on?"":"No devices answered. Check the range, or that ping is allowed.");
  $("csv").disabled=!devices.length;render();
}
function setMsg(t,err){$("msg").textContent=t;$("msg").className="msg"+(err?" err":"")}
function pos(ip){const o=ip.split(".").map(Number),a=(o[3]/256)*2*Math.PI-Math.PI/2,r=50+((o[3]*47+o[2]*13)%125);
  return [200+r*Math.cos(a),200+r*Math.sin(a)]}
function render(){
  const g=$("blips"),ul=$("list");g.replaceChildren();ul.replaceChildren();
  [...devices].sort((a,b)=>b.online-a.online).filter(d=>d.online).forEach(d=>{
    const [x,y]=pos(d.ip);
    const h=document.createElementNS(svgNS,"circle");h.setAttribute("class","halo");h.setAttribute("cx",x);h.setAttribute("cy",y);h.setAttribute("r",14);
    const b=document.createElementNS(svgNS,"circle");b.setAttribute("class","blip");b.setAttribute("cx",x);b.setAttribute("cy",y);b.setAttribute("r",6);b.dataset.ip=d.ip;
    const t=document.createElementNS(svgNS,"title");t.textContent=d.ip;b.append(t);
    b.onclick=()=>pick(d.ip);g.append(h,b);
    const li=el("li");li.dataset.ip=d.ip;li.onclick=()=>pick(d.ip);
    li.append(el("span","dot"),el("span","ip",d.ip));
    li.append(el("span","meta",(d.host!=="Unknown"?d.host:"Name not shared")+"  |  "+(d.mac!=="-"?d.mac:"MAC not visible")));
    const c=el("div","chips");d.ports.forEach(p=>c.append(el("span",null,`${p.port} ${p.name}`)));
    if(!d.ports.length)c.append(el("span",null,"no open ports found"));
    li.append(c);ul.append(li);
  });
}
function pick(ip){selected=ip;
  document.querySelectorAll("[data-ip]").forEach(n=>n.classList.toggle("on",n.dataset.ip===ip));
  const li=document.querySelector(`li[data-ip="${ip}"]`);li&&li.scrollIntoView({block:"nearest",behavior:"smooth"})}
$("csv").onclick=()=>location.href="/api/csv";
</script></body></html>"""


def main():
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    url = f"http://127.0.0.1:{PORT}"
    print(f"PyNet Web running at {url}  (Ctrl+C to stop)")
    threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
